<div class="container bg-gray-600 h-10 max-w-full mt-10 text-white flex justify-center items-center p-8">
    <span>دانشگاه فنی تبریز - حسن وجدی</span>
</div>